import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { searchFilms } from '../api';
import Loading from './Loading';

function SearchPage() {
  const [query, setQuery] = useState('');
  const [films, setFilms] = useState([]);
  const [loading, setLoading] = useState(false);
  const [suggestions, setSuggestions] = useState([]);
  const navigate = useNavigate();

  // Debounce для автодополнения
  useEffect(() => {
    const timer = setTimeout(() => {
      if (query.trim() !== '') {
        searchFilms(query)
          .then(data => {
            setSuggestions(data.slice(0, 10));
          })
          .catch(err => console.error(err));
      } else {
        setSuggestions([]);
      }
    }, 300);
    return () => clearTimeout(timer);
  }, [query]);

  const handleSearch = () => {
    setLoading(true);
    searchFilms(query)
      .then(data => {
        setFilms(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  };

  return (
    <div className="search-page container">
      <h2>Поиск фильмов</h2>
      <div>
        <div className="search-wrapper">
          <input
            type="text"
            placeholder="Найти фильм..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          {suggestions.length > 0 && (
            <ul className="suggestions">
              {suggestions.map(film => {
                const title = film.nameRu || film.nameOriginal || 'Без названия';
                const year = film.year ? ` (${film.year})` : '';
                return (
                  <li
                    key={film.filmId}
                    onClick={() => navigate(`/film/${film.filmId}`)}
                  >
                    {title + year}
                  </li>
                );
              })}
            </ul>
          )}
        </div>
        <button onClick={handleSearch}>Поиск</button>
      </div>

      {loading && <Loading size="30px" />}

      <div className="film-list">
        {films && films.map(film => {
          const title = film.nameRu || film.nameOriginal || 'Без названия';
          const year = film.year ? ` (${film.year})` : '';
          return (
            <div
              key={film.filmId}
              className="film-card"
              onClick={() => navigate(`/film/${film.filmId}`)}
            >
              <img
                src={film.posterUrlPreview || film.posterUrl || '/assets/placeholder.jpg'}
                alt={title}
              />
              <p>{title + year}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default SearchPage;
