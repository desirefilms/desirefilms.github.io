import React from 'react';
import { useNavigate } from 'react-router-dom';

function Header() {
  const navigate = useNavigate();

  return (
    <header>
      <div className="logo">
        {/* Используем PNG-логотип */}
        <img src="/assets/logo.png" alt="Desire Logo" />
      </div>
      <h1>Desire</h1>
      <nav>
        <button onClick={() => navigate('/')}>Поиск</button>
        <button onClick={() => navigate('/collections')}>Подборки</button>
      </nav>
    </header>
  );
}

export default Header;
