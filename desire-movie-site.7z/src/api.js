// Замените на ваш действующий API‑ключ от kinopoiskapiunofficial.tech
const KP_API_KEY = 'b9e247a6-046e-4c29-bc5f-2b131432be36';

export async function searchFilms(query) {
  const url = `https://kinopoiskapiunofficial.tech/api/v2.1/films/search-by-keyword?keyword=${encodeURIComponent(query)}`;
  const response = await fetch(url, {
    headers: {
      'X-API-KEY': KP_API_KEY,
      'Content-Type': 'application/json'
    }
  });
  if (!response.ok) {
    throw new Error(`Ошибка поиска: ${response.status}`);
  }
  const data = await response.json();
  return data.films;
}

export async function getFilmDetails(id) {
  const url = `https://kinopoiskapiunofficial.tech/api/v2.2/films/${id}`;
  const response = await fetch(url, {
    headers: {
      'X-API-KEY': KP_API_KEY,
      'Content-Type': 'application/json'
    }
  });
  if (!response.ok) {
    throw new Error(`Ошибка получения деталей: ${response.status}`);
  }
  return await response.json();
}

export async function fetchStreamingSources(kinopoiskId) {
  const url = new URL('https://kinobox.tv/api/players');
  url.searchParams.set('kinopoisk', kinopoiskId);
  url.searchParams.set('sources', 'alloha,ashdi,cdnmovies,collaps,hdvb,kodik,vibix,videocdn,voidboost');
  const response = await fetch(url.toString());
  if (!response.ok) {
    throw new Error(`Ошибка запроса источников: ${response.status}`);
  }
  const data = await response.json();
  return data.filter(item => item.iframeUrl && item.success && item.source);
}

export async function getFilmCollections(collection = 'TOP_POPULAR_ALL', page = 1) {
  const url = new URL('https://kinopoiskapiunofficial.tech/api/v2.2/films/collections');
  url.searchParams.set('collection', collection);
  url.searchParams.set('page', page);
  const response = await fetch(url.toString(), {
    headers: {
      'X-API-KEY': KP_API_KEY,
      'Content-Type': 'application/json'
    }
  });
  if (!response.ok) {
    throw new Error(`Ошибка получения подборок: ${response.status}`);
  }
  return await response.json();
}
